fx_version 'cerulean'
game 'gta5'

author 'YourName'
description 'Custom Carry Script for QBCore'
version '1.0.0'

shared_scripts { '@qb-core/shared.lua' }
client_script 'client.lua'
server_script 'server.lua'
