QBCore = exports['qb-core']:GetCoreObject()

local isCarrying = false
local carriedPlayer = nil

RegisterNetEvent('m-carry:startCarry', function(targetId)
    local playerPed = PlayerPedId()
    local targetPed = GetPlayerPed(GetPlayerFromServerId(targetId))

    if isCarrying then
        StopCarry()
    else
        if DoesEntityExist(targetPed) then
            isCarrying = true
            carriedPlayer = targetPed
            AttachEntityToEntity(targetPed, playerPed, 0, 0.15, 0.45, 0.65, 0.0, 0.0, 0.0, false, false, false, false, 2, true)
            TriggerServerEvent('m-carry:syncCarry', targetId, true)
        end
    end
end)

RegisterNetEvent('m-carry:stopCarry', function()
    StopCarry()
end)

function StopCarry()
    if isCarrying and carriedPlayer then
        DetachEntity(carriedPlayer, true, true)
        isCarrying = false
        carriedPlayer = nil
        TriggerServerEvent('m-carry:syncCarry', GetPlayerServerId(PlayerId()), false)
    end
end

RegisterKeyMapping('carry', 'Toggle Carry', 'keyboard', 'G')

RegisterCommand('carry', function()
    local closestPlayer, closestDistance = QBCore.Functions.GetClosestPlayer()
    if closestPlayer ~= -1 and closestDistance < 3.0 then
        TriggerServerEvent('m-carry:requestCarry', GetPlayerServerId(closestPlayer))
    else
        QBCore.Functions.Notify('No players nearby!', 'error')
    end
end, false)

exports('StartCarry', function(targetId)
    TriggerServerEvent('m-carry:requestCarry', targetId)
end)
