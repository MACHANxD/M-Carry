QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent('m-carry:requestCarry', function(targetId)
    local source = source
    TriggerClientEvent('m-carry:startCarry', targetId, source)
end)

RegisterNetEvent('m-carry:syncCarry', function(targetId, state)
    TriggerClientEvent('m-carry:stopCarry', targetId, state)
end)
